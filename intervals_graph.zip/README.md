## Create an .env file
Make sure you create a .env file as it will store the "API_KEY" value. 
Also make sure to have your "ATHLETE_ID" added to it.
This file is not in this repo for security reasons.

