# config/settings.py
API_BASE_URL = "https://intervals.icu/api/v1/"
OLDEST_DATE = "1970-01-01"
NEWEST_DATE = "2025-01-01"
PORT = 8080
OUTPUT_DIR = "output"
